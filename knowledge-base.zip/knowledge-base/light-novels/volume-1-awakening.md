# INFINITE IDOL - Volume 1: The Awakening Arc

*She Woke Up Outside the Tournament With No Memories and Apparently She Has to Chase Down Some Guy Called "Senpai" or Literally Stop Existing?!*

---



## Chapter 0


## Prologue: In Which the Author Acknowledges What Kind of Story This
Is

Before we begin, let me be completely honest with you.

This is a story about attractive people in revealing outfits chasing a
mysterious pretty boy across obstacle courses while their clothes
strategically malfunction, all in service of generating enough
'emotional energy' from their fans to avoid being erased from
existence.

If you're looking for subtle literary fiction, you're in the wrong
book.

If you're looking for a story where the protagonist is modest, demure,
and embarrassed by her own body, you're definitely in the wrong book.

But if you're looking for a story about a shameless disaster of a woman
who wakes up with no memories, discovers she's apparently already
famous for being hot and talented, and decides to lean into it so hard
that the entire establishment wants her dead?

Welcome.

My name is Ika Minami, and this is the story of how I refused to
disappear.


---


*(The preceding message was added by the protagonist against the
author's wishes. She insisted it was 'important for setting
expectations.' The author has given up on controlling her.)*


## Chapter 1

The First Thing I Felt Was Concrete, Which Really Set the Tone for
Everything That Followed

The first thing I felt was concrete.

Cold, wet, deeply uncomfortable concrete pressing against my cheek like
the physical manifestation of poor life decisions.

For a long moment, I just lay there, trying to piece together how I'd
ended up in this situation. My brain felt like someone had taken all my
memories, put them in a blender, and then served me a smoothie with half
the ingredients missing.

*Okay, I thought, running through the possibilities. Either I've been
reincarnated into a fantasy world, or last night was significantly more
eventful than I can currently remember.*

I waited for the truck-kun flashback. The divine being offering me cheat
skills. The harem of beautiful people ready to fall in love with me for
no adequately explained reason.

Nothing.

Just concrete. And noise---distant, pulsing, alive. Music and cheering
and what sounded like a stadium full of people losing their collective
minds over something.

And was that someone screaming 'SENPAI, WAIT!'?

I pushed myself up onto my elbows, and immediately regretted it as my
head throbbed in protest. Pink hair fell across my vision---gradient,
shifting from pale rose at the roots to deep magenta at the tips.

*Cute, I thought. I don't remember choosing that color, but past-me had
taste.*

Then I looked down at myself.

And stopped.

And looked again, just to make sure I wasn't hallucinating.

*Oh.*

*Oh, those are\... generous.*

The kind of proportions that got character designs rejected by committee
for 'lacking realism.' The kind that made clothing a structural
engineering challenge. The kind that I somehow knew, instinctively, I
had never once apologized for.

I was wearing what appeared to be athletic wear, though the term was
doing a lot of heavy lifting. Sports bra variant, very short shorts,
thigh-high socks. Everything was pink and black and barely there.

*I can work with this, I thought.*

And somewhere deep in my fragmented memory, that felt exactly right.


---


"HEY! HEY HEY HEY!"

A blur of purple and teal slammed into existence beside me, skidding to
a stop with the grace of an energy drink commercial directed by someone
who was also on energy drinks.

The girl crouching over me was athletic in a way that made fitness
influencers weep with envy. Visible abs. Toned thighs. Arms that looked
like they could bench press my entire life's problems. She was wearing
even less than I was---crop top, tiny shorts, running shoes---and seemed
completely unbothered by it.

Her hair was purple and teal in a wild gradient, sticking up in ways
that suggested either careful styling or a recent electrical accident.
Her eyes were bright purple and practically vibrating with energy.

She also had bandaids on both knees, which raised questions I wasn't
sure I wanted answered.

"YOU ALIVE?!" she demanded, leaning into my personal space with zero
concept of boundaries. "You look super not-alive! Well, not NOT-alive,
but definitely not optimally alive!"

Before I could respond, her eyes drifted downward.

Very obviously downward.

"Also---" She paused. Stared. Made absolutely no effort to pretend she
wasn't staring. "---wow. Just. Wow."

"\...Are you checking me out?" I managed.

"I'm looking respectfully!" She held up her hands in a gesture that
was probably meant to be innocent but really wasn't. "Okay, maybe
sixty percent respectfully. Fifty-five."

I considered being offended. I really did.

But something in my swiss-cheese memory told me this was familiar.
Normal, even. Like I'd spent a long time being looked at, and had made
peace with it somewhere along the way.

"Fair enough," I said instead. "Where am I? And who are you?"

The girl's grin could have powered a small city.

"I'm SORA!" She struck a pose that involved entirely too much hip
movement for what was supposedly a rescue operation. "Fastest idol in
three generations! I hold the record for Senpai captures AND the record
for most faceplants during Senpai captures! Both are points of pride!"

"\...Senpai captures?"

"We'll get to that!" She grabbed my hand with a grip that was
surprisingly strong. "Point is, you're lying outside the Eternal Stage
looking like someone factory-reset your brain, and the TOURNAMENT is
happening RIGHT NOW, so we need to figure out your whole deal
immediately!"

"I'm\... I think my name is Ika?"

Sora's eyes went wide.

"You THINK?!" Her voice hit a pitch that probably startled dogs in
other dimensions. "Oh no. Ohhhh no. You're a Fresh Bloom, aren't you?
Just manifested? Memories still buffering?"

"I don't understand anything you're saying."

Something softened in her manic expression. Just for a moment, beneath
all that chaos energy, I caught a glimpse of something almost gentle.

"Yeah," she said quietly. "That tracks."

Then the energy snapped back on like someone had flipped a switch.

"Okay, newbie! Let me explain everything!" She hauled me to my feet
with one arm, which was both helpful and an unnecessary display of how
strong she was. "Fair warning: it's gonna sound fake. It's not fake.
Also, it's going to sound like the plot of a very specific type of
anime."

"What type?"

"The type where attractive people compete in revealing outfits while
reality makes their clothes fall off." She said this completely
matter-of-factly, like she was describing the weather. "Because
apparently that's just how the universe works here."

"That's not reassuring."

"I know, right?!" She grabbed my hand and started pulling me toward
the source of all the noise. "LET'S GO!"


---


The Eternal Stage was impossible.

That's not hyperbole. It was genuinely, architecturally, physically
impossible---a structure that hurt to look at directly because my brain
couldn't process what it was seeing.

Crystalline spires reached toward a sky that had too many horizons.
Holographic displays the size of weather systems broadcast competitions
in every direction. Racing circuits spiraled around combat arenas that
floated beside concert halls that existed next to gaming centers.
Everything pulsed with light and sound and the overwhelming sense that
reality was showing off.

"Welcome to the tournament grounds," Sora said, spreading her arms
wide. "Every generation, idols from across existence compete here.
Racing. Fighting. Performing. Gaming. Dancing. Sometimes cooking, if the
ratings need a boost."

"Idols?"

"People like us!" She gestured at herself, at me, at the dozens of
other attractive people moving through the area in various states of
athletic undress. "People who can make audiences FEEL things so
intensely that it becomes actual power!"

I stared at her.

"\...Feelings are power?"

"Devotion is power!" She bounced on her heels, unable to stay still.
"When you watch something amazing---a performance that takes your
breath away, or someone being so impressive your brain
short-circuits---that emotional response generates energy. Real, actual,
measurable energy."

She grabbed my shoulders, eyes intense.

"And people who can generate enough of it? We become MORE. More real.
More permanent. More PRESENT in the fabric of existence itself."

"So simping is a power source."

"When you put it like that it sounds---" She paused. "Actually, yeah.
That's exactly what it is. We're basically powered by parasocial
relationships."

"And the Senpai thing?"

Sora's grin became enormous.

"Oh, you're gonna LOVE this."

She dragged me to a viewing area overlooking one of the main competition
venues, and I finally understood what all the screaming was about.


---


THE CHASE.

That's what they called it, and honestly, no other name would have fit.

The course was a three-dimensional nightmare of obstacles---climbing
walls at impossible angles, balance beams over void, rope swings
connecting platforms, parkour sections that seemed designed by sadists
with a grudge against the laws of physics.

And running through it all, pursued by a pack of athletic women in
increasingly compromised outfits, was a single figure.

Senpai.

He was attractive---that much was obvious even from this distance.
Athletic build, dark hair, movements that made gravity look like a
polite suggestion rather than a law. He parkoured over obstacles with
supernatural grace, always just ahead, always just out of reach.

His face, I noticed, was somehow never quite visible. Dramatic
backlighting. Convenient angles. Motion blur at exactly the right
moments. It was like the universe itself was conspiring to keep him
mysterious.

Behind him, the idols chased.

They climbed. They leaped. They swung from ropes and sprinted across
balance beams and pushed their bodies to absolute limits.

And their outfits\... suffered.

Straps slipping on climbing walls. Fabric straining during stretches.
Strategic casualties during high-impact landings. It was like the course
itself was at war with the concept of clothing.

The crowd was going absolutely nuclear.

"The first idol to catch Senpai wins the round," Sora explained
cheerfully. "But it's not just about speed---it's about STYLE. How
you chase. How you climb. How you look while doing it. How you
handle\..." She gestured vaguely at an idol whose top had just lost a
dramatic battle with physics. "\...wardrobe logistics."

I watched the chaos unfold.

An idol made a diving grab for Senpai's shirt, caught the hem, got
dragged three feet before losing her grip. Her shorts didn't survive
the experience. The crowd screamed.

Another idol tried a flanking maneuver across a balance beam, almost
caught him, then lost her footing at the last second. Her landing was
graceful. Her outfit was not. The crowd screamed louder.

"This is insane," I said.

"This is PEAK ENTERTAINMENT!" Sora's eyes were shining. "Think about
it! Athletic competition! The thrill of the chase! The primal appeal of
pursuit! Plus you get to watch hot people do parkour in outfits that
were never designed for parkour!"

"It's fetish content with extra steps."

"It's fetish content with ATHLETIC steps! The audience LOVES it!"

I couldn't argue with that. The crowd was generating enough enthusiasm
to power a small nation.

But something else was nagging at me.

"Why does he run?"

"What?"

"Senpai. Why does he run? Why not just\... let someone catch him?"

Sora paused. Blinked. Her expression suggested this question had
genuinely never occurred to her.

"That's\... huh. That's actually a really good question." She
scratched her head. "I think it's just\... the rules? The Chase
doesn't work if he doesn't run. The wanting is the point."

"Has anyone ever asked him?"

"I don't think anyone's ever caught him long enough to have a
conversation." She shrugged. "He's basically a cryptid who's really
good at cardio."

I filed that away for later consideration.

"You said there were stakes," I said. "What happens if you lose?"

The light in Sora's eyes dimmed slightly.

"Ah," she said. "Yeah. We should probably talk about that."


---


"So here's the deal," Sora said, and for the first time since I'd
met her, she wasn't bouncing.

We'd found a quieter spot away from the main venue. The crowd noise was
still audible, but muted enough that I could actually think.

"Idols exist because people care about us," she continued. "Their
attention, their devotion, their emotional investment---that's what
makes us real. We're not like regular people. We're more like\...
living legends? Stories that walk around?"

"That sounds fake."

"I told you it would." She hugged her knees, and suddenly looked much
younger than her manic energy had suggested. "The thing about legends
is, they need to be remembered. If people stop watching you, stop caring
about you, stop feeling things when they see you\..."

"What happens?"

"You Fade."

The word hung in the air, heavier than it should have been.

"First, your performances get forgotten," Sora said quietly. "Fans
who loved you just\... don't remember why. Then your face gets fuzzy in
their memories. Then your name."

She made a gesture like smoke dispersing.

"Eventually, you just stop existing. Like you never were. Even the
people who knew you forget you were ever real."

Cold settled in my chest.

Not because the concept was scary---though it was---but because
something in my fragmented memory was responding to it. A deep, visceral
recognition.

*The fear of being invisible. The desperation of performing to empty
rooms. The feeling of screaming into a void that didn't care.*

"That's terrifying," I said.

"That's why we compete." Some of Sora's energy returned, though it
felt more forced now. "The tournament concentrates MASSIVE amounts of
devotion. Winners achieve Eternal Fame---like, literally eternal. You
become a legend that can never be forgotten."

"And losers?"

"\...Accelerated Fade." She winced. "The tournament is high-risk,
high-reward. You burn bright or burn out."

I let that sink in.

"So it's a death game," I said finally. "A sexy death game where the
weapon is parasocial relationships."

"When you put it like THAT---"

"Am I wrong?"

"\...No." She sighed. "You're really not."

We sat in silence for a moment, the distant cheering a strange
counterpoint to the heaviness of the conversation.

Then Sora's grin returned, sharp and determined.

"But here's the thing," she said. "You? You're not just some random
amnesiac who woke up outside the Stage."

She pulled up a holographic display from her wrist.

"You're already famous."


---


The footage showed a Chase course during what was clearly a qualifier
event.

The course was brutal---vertical climbing sections, balance beams, rope
swings, the works. Most competitors were struggling, their trained
bodies pushed to the limit.

And then there was me.

Past-me wore an outfit that could generously be described as
'present.' It covered the legal minimum and absolutely nothing else.
On anyone else, it would have been a disaster for athletic performance.

On me, it looked like a deliberate choice. A statement.

I watched myself scale a climbing wall in seconds, movements efficient
and confident. I watched myself swing from a rope with a hip rotation
that was aerodynamically useless but visually spectacular. I watched
myself chase Senpai across a balance beam while making eye contact with
the camera and winking.

"LOOK at that wall climb!" Sora was practically vibrating. "You
scaled that in like four seconds! And the rope swing---nobody does a
mid-air pose like that! It's completely pointless but the STYLE!"

On screen, past-me caught up to Senpai on a narrow platform.

Instead of immediately grabbing him, I---she---I posed. Actually posed,
one hand on hip, head tilted, like I had all the time in the world.

Then I made my move.

A diving tackle that somehow looked graceful. We tumbled onto a landing
platform, and when the motion stopped, I was straddling him, barely out
of breath, outfit having suffered strategic casualties that somehow only
enhanced the visual.

The crowd in the footage went absolutely nuclear.

"Ten thousand devoted fans in six hours," Sora said. "From
forty-seven regular viewers to a qualifying threshold, just like that.
Do you know how IMPOSSIBLE that is?"

"I\... did that?"

"You DESTROYED that! But wait---this is the best part!"

She scrubbed forward in the footage.

Past-me, still straddling Senpai, leaned down to whisper something in
his ear. The camera couldn't pick up what was said, but it caught the
aftermath.

Senpai blushed.

Actually, visibly, unmistakably blushed.

"Nobody knows what you said to him," Sora breathed. "It's the
biggest mystery of the qualifier season. People have written ESSAYS
speculating."

"I don't remember either," I admitted.

"That makes it BETTER! The mystique!"

I stared at my past self on the screen. Confident. Shameless. Utterly in
control.

Something stirred in my chest. Recognition. Pride. Hunger.

"I look like I was having fun," I said quietly.

"You looked like you were telling the entire establishment to kiss your
extremely well-presented ass." Sora's grin was sharp and delighted.
"And THAT is why I had to find you."

She grabbed my hand.

"Welcome to Infinite Idol, you beautiful disaster. Let's cause some
problems."


## Chapter 2

In Which I Learn About the Power Structure and Accidentally Commit to
a Friendship Through the Power of Complimenting Someone's Chest

"The idol world has tiers," Sora explained as we walked through the
tournament grounds. "Like a food chain, but for hot people."

Other competitors moved around us---stretching, warming up, practicing
climbing techniques on training walls. Most of them were attractive in
that polished, professional way that suggested money and management and
careful curation.

Some of them glanced at me with recognition.

Others glared with hostility that suggested I'd personally wronged them
in a past life.

"Why do they hate me?" I asked.

"Because you're either a threat or an insult, depending on how they
see it." Sora shrugged. "You bypassed the whole system. No training
academy. No management contract. No expensive debut campaign. You just
showed up, looked incredible, and took what they spent years working
toward."

"I can see how that might be annoying."

"Annoying is an understatement. Some of these girls have been in the
pipeline since childhood. And then you waltz in with your---" She
gestured vaguely at my general everything. "---and generate more
devotion in six hours than they do in a year."

"Sounds like a them problem."

Sora laughed, bright and sharp. "Oh, I REALLY like you."

We came to a massive golden statue dominating a plaza.

It depicted a woman of impossible elegance---flowing hair reaching her
ankles, elaborate gown that covered everything while somehow being the
most seductive thing I'd ever seen. She radiated authority and grace
even in metal form.

"Himeko Ichiban," Sora said, her voice dropping into something almost
reverent. "The First. The one who discovered that audience devotion
could become actual power."

"She's still around?"

"She's ETERNAL. Like, literally. She doesn't compete
anymore---doesn't need to. But sometimes she shows up to remind
everyone that we're all just following the path she created." Sora
tilted her head. "They say she's never shown so much as an ankle, and
yet she has more devoted fans than anyone in history."

"The ultimate tease."

"The ultimate EVERYTHING. She invented the Chase, you know. The whole
format."

"She invented chasing guys as a sport?"

"She invented making the PURSUIT into entertainment. She understood
that the wanting generates more power than the having. That's why
Senpai runs---because desire is strongest for what you can't quite
reach."

I looked at the statue with new appreciation.

"That's actually brilliant."

"She's the original girlboss. Figured out that humanity's collective
thirst could power reality itself."


---


The next statue was different.

Crystal instead of gold. Sharp angles instead of flowing lines. A woman
in sophisticated athletic wear that was technically modest and somehow
implied everything. Perfect posture. Legs that went on forever. An
expression that looked down at you even in statue form.

"And THAT," Sora said, and there was an edge in her voice now, "is
Erina."

"She looks intense."

"She built the entire modern idol infrastructure. Training academies.
Management agencies. Ranking systems. Media networks." Sora kicked a
pebble. "If you want to become an idol the 'proper' way, you go
through her system."

"Let me guess: it costs money."

"Resources. Connections. Money. AND you have to kiss the ring."
Sora's jaw tightened. "Her training produces genuinely amazing idols,
so it's not like she's gatekeeping for no reason. But it's\...
centralized. Controlled. Not exactly welcoming to people who can't
afford the entry fee."

"And I bypassed all of it."

"You DEMOLISHED it." Some of her grin returned. "Showed up uninvited,
looked incredible, performed amazingly, and generated more organic
devotion than most officially-backed debuts. The establishment is
FURIOUS."

"What did she say about me?"

"That your qualifying run was 'vulgar,' 'unrefined,' and
'pandering to base instincts.'" Sora paused. "She also admitted you
understood the assignment perfectly, which from her is basically a
marriage proposal."

I felt a spark of satisfaction at that.

*Good, some part of me thought. Let them be mad.*


---


"What about you?" I asked. "Where do you fit in all this?"

Sora struck a pose---hand on hip, chin lifted, maximum dramatic energy.

"Top-tier speedster! Fastest idol in three generations! I hold the
record for most Senpai catches in a single season!"

"That sounds impressive."

The pose faltered slightly.

"Also the record for most falls. Most crashes. Most 'technical
difficulties.'" She made air quotes. "Sometimes I push too hard and
just\... crash. Full system shutdown. Wake up thirty seconds later like
nothing happened."

"That sounds painful."

"The fans actually like it?" She shrugged, but the casualness felt
forced. "Apparently watching me destroy myself trying is 'relatable.'
It's fine. I just need to go faster. Push harder. Then I won't crash
anymore."

I studied her.

Beneath all that manic energy, I could see it now---the exhaustion. The
desperation. The fear that she wasn't enough unless she was breaking
herself to prove it.

"You know you don't have to destroy yourself to be loved, right?"

Sora froze.

For a moment, the mask cracked. I saw something raw and vulnerable
underneath---a girl who'd been running so fast for so long that she'd
forgotten why.

Then the grin snapped back into place, bright and brittle.

"WOW okay getting personal fast! Love the energy!" She grabbed my
hand. "Let's go meet someone who can actually help with your memory
thing!"

She was already pulling me forward before I could respond.

I noted that her grip was trembling slightly.

*We'll talk about that later, I promised silently. When you're ready.*


---


We found Suiren in a private training facility that looked like it cost
more than most people's lifetime earnings.

She was running through a climbing wall simulation when we entered, and
for a moment, I just watched.

The word 'graceful' didn't do it justice.

She moved like water flowing upward---each handhold found without
looking, each movement flowing into the next with the effortless
precision of someone who'd practiced this ten thousand times until it
became as natural as breathing. Her blue-teal hair drifted behind her
like she existed in a different relationship with gravity than the rest
of us.

Her athletic wear was elegant and devastating. Technically functional.
Strategically revealing. The kind of thing that looked modest until she
stretched and then very much didn't.

She was beautiful and cold and absolutely perfect.

She dropped from the wall when we entered, landing silently. Cool cyan
eyes assessed me with the precision of a very pretty spreadsheet.

"Sora." Her voice was calm, measured---the vocal equivalent of a still
lake with something dangerous lurking in its depths. "This is the
disruption."

"This is IKA!" Sora bounced. "She's the qualifying sensation but
doesn't remember BEING the qualifying sensation! Very mysterious and
extremely---"

"Please don't say 'extremely hot.'"

"I was going to say 'extremely athletic!' But also hot! Both things
can be true!"

Suiren approached me.

I held my ground.

Something in me refused to flinch, even in the face of all that
cool-beauty energy.

"Your qualifying run has been analyzed extensively," she said,
circling me slowly. Assessing. "Your climbing technique is unorthodox.
Your pursuit strategy is chaotic. Your outfit choices were\..." A
pause. "\...transparent in their intent."

"Is there a 'but' coming?"

"But." The ghost of a smile touched her lips---so faint I might have
imagined it. "You caught Senpai. Through raw instinct and shameless
confidence, you achieved what trained idols spend years attempting."

"You're not here to lecture me about proper technique?"

"I am here because you interest me."

She stopped in front of me. Up close, I could see that her perfection
had cracks---tiny signs of exhaustion, of loneliness, of something
hungry lurking beneath the ice.

"Everyone admires my technique," she said quietly. "They see perfect
movement, flawless execution. But they see a machine, not a person."
Her gaze dropped for just a moment. "You seem incapable of being
anything other than yourself. I wish to understand how that functions."

I considered her.

In my fragmentary memories, I found echoes of loneliness---the isolation
of performing to empty rooms, of being seen but not known. I recognized
that hunger in her eyes because I'd felt it too.

"Okay," I said. "Partners. But you should know something about me
first."

"Yes?"

I met her eyes directly. No shame. No hesitation.

"Your chest looks AMAZING in that outfit."

In the corner of my vision, Sora made a sound like a tea kettle
achieving enlightenment.

Suiren blinked once. Twice.

Her expression didn't change, but something shifted behind her
eyes---surprise, maybe. Or the ghost of amusement.

"Thank you," she said, completely deadpan. "Yours are also\...
structurally impressive."

"We're gonna be best friends."

"I believe that assessment is accurate."

Behind us, Sora was frantically taking photos.

"For POSTERITY! This is HISTORICAL! The birth of a LEGENDARY
PARTNERSHIP! The fans are gonna SHIP this so hard!"

"They already are," Suiren said flatly. "I checked the forums after
your qualifying run. 'IkaSui' is trending."

"WE HAVEN'T EVEN DONE ANYTHING YET!"

"The fanart is already extensive. Some of it is quite\... creative."

I grinned.

Something about this felt right. The chaos energy of Sora, the cool
precision of Suiren, and whatever I was---we fit together like pieces of
a puzzle designed by someone with questionable taste but excellent
instincts.

"Alright," I said. "So what's first? Training? Strategy? Figuring
out who scrambled my brain?"

Sora and Suiren exchanged looks.

"Actually," Suiren said, "we should probably discuss that last one."

"The brain scrambling?"

"Someone did this to you deliberately." Her eyes were cold. "And we
need to find out why."


## Chapter 3

My Memories Return and It Turns Out Past-Me Was Even More of a
Disaster Than I Expected (Affectionate)

That night, in quarters that Suiren had arranged, my memories came back.

All of them.

All at once.

I sat bolt upright in bed, gasping, as my entire life crashed back into
my consciousness like a wave I hadn't seen coming.


---


My name was Ika Minami, and I had been a nobody.

The small apartment. The screens glowing in darkness. The endless,
endless hours of streaming to empty rooms---gaming, chatting, working
out, doing whatever I could think of to get anyone, ANYONE, to notice I
existed.

I remembered the view counts. The single digits that felt like personal
attacks. The rare spikes when I wore something revealing or said
something provocative, followed by the inevitable crash when the clicks
didn't convert to anything lasting.

I remembered getting banned from three platforms for 'borderline
content' when all I'd done was refuse to pretend I didn't know what
my body looked like.

I remembered the comments. The ones that called me desperate. The ones
that said I was degrading myself. The ones that asked why I didn't just
give up.

And I remembered the forty-seven.

My real fans.

Not the bots---though I'd appreciated them too, honestly, at least they
showed up---but the actual humans who came back every stream. Who
donated money they probably couldn't afford. Who laughed at my jokes
and called me out when I was being stupid and made me feel like I
wasn't screaming into a void.

Forty-seven people who genuinely liked me.

Not despite the fanservice. BECAUSE of the honesty behind it.

They'd understood what I was doing and respected that I was doing it on
my own terms. No fake innocence. No coy pretense. Just shameless,
authentic acknowledgment of exactly what I was selling and why.

*"If I'm going to use my body as a selling point," I'd said once,
during a late-night stream when my defenses were down and I was being
more honest than usual, "I'm going to OWN it. I worked hard for this.
I'm not going to pretend I don't know what I'm doing."*

That clip had gotten me banned from platform number three.

It had also gotten me my most loyal supporters.


---


I remembered discovering the Infinite Idol Tournament.

Watching the Chase events with growing fascination. The athleticism. The
drama. The spectacular disasters and triumphant catches. Idols pushing
their bodies to the limit while their clothes strategically failed.

I remembered thinking: I could do that.

I remembered thinking: I could do that BETTER.

I remembered the conversation with my forty-seven, late one night when
the desperation was stronger than usual.

*"I'm going to crash the qualifiers," I'd told them. "No backing.
No training. Just me and whatever I've got."*

*"That's insane," someone had typed. "You'll get destroyed."*

*"Probably," I'd agreed. "But I'd rather flame out spectacularly
than flicker away in silence."*

They'd believed in me anyway. Spread the word. Brought their friends.

And when the stream started, something had happened.


---


I remembered the qualifying run.

Six hours of giving everything---every ounce of athleticism I'd built
from years of workout streams nobody watched, every drop of shameless
confidence I'd cultivated, every skill I'd practiced alone in my room.

The climbing walls. The balance beams. The rope swings. Every obstacle
designed to break me, and I'd made them look like dance floors.

I remembered the outfit---minimal by design, because I knew exactly what
I was doing. If they were going to look anyway, I was going to make sure
they remembered what they saw.

I remembered the moment I caught Senpai.

The diving tackle. The tumble. The landing that put me on top of him,
barely out of breath, outfit strategically damaged in all the right
places.

And I remembered what I'd whispered in his ear.

*"Thanks for the workout, but I'm just getting started."*

He'd blushed because nobody had ever talked to him like that before. To
everyone else, he was a prize. A MacGuffin. A goal to be achieved.

To me, he was just a guy who was really good at cardio.

The crowd had lost their minds. The view count had exploded. And
somewhere in those six hours, forty-seven had become ten thousand.

Ten thousand devoted fans. The threshold that meant you mattered. That
you were real.

I'd manifested here. Entered the tournament. Become an Idol with a
capital I.

And then\...


---


And then the gap.

I pushed harder, trying to remember what came next, and hit a wall. Not
emptiness---something deliberate. A barrier where memories should be.

Someone had done this to me.

Someone had reached into my head and tried to cut out everything that
made me who I was.

The fear. The desperation. The hunger that had driven me to crash a
tournament I had no right to enter. The forty-seven faces I could now
see clearly, the people who'd believed in me when no one else did.

Someone had tried to take all of that away.

And they'd failed.

I stared at myself in the mirror across the room. Pink gradient hair.
Athletic body. Eyes that knew exactly what they were doing.

"Okay," I said to my reflection. "Someone tried to delete me."

The reflection smiled. It wasn't a nice smile.

"Let's show them what a mistake that was."


## Chapter 4

The Conspiracy Reveals Itself and I Discover That Spite Is an
Excellent Motivator

"Someone tampered with your memories," Suiren said without preamble.

It was the next morning. We'd gathered in the common area of the
quarters she'd arranged---me, Sora, and Suiren forming a small triangle
of conspiracy and concern.

"The gap wasn't natural," she continued. "I analyzed the patterns in
your cognitive response. Someone with significant influence attempted to
sever your connection to your own history."

"They tried to make her Fade early," Sora said, her usual energy
muted. "Cut her off from what made her HER, and hope she dissolved
before she could figure out what happened."

"Why?" I asked, though I already suspected the answer.

Suiren's cool eyes met mine.

"Because you represent a threat to established power structures. You
proved that an idol can achieve recognition without going through the
proper channels. Without training academies, management contracts,
institutional approval." She paused. "If you succeed in this
tournament\..."

"It proves the system isn't necessary," I finished.

"Precisely."

"And some people have invested a LOT in that system," Sora added
darkly.

I processed this.

Somewhere in my chest, something that had been simmering since my
memories returned began to boil.

"So let me make sure I understand," I said slowly. "Someone tried to
ERASE me---not just beat me, but completely delete everything that makes
me who I am---because I was too good at being hot and talented without
permission?"

"That is\... an accurate summary, yes."

"And instead of disappearing like they wanted, I woke up outside the
Eternal Stage with partial amnesia and got found by the two of you."

"Correct."

I stood up.

Sora and Suiren watched me.

"Then I'm going to win this entire tournament," I said, and my voice
was calm in a way that felt dangerous even to me. "Not just compete.
Not just survive. WIN. So thoroughly and completely that whoever did
this has to watch me succeed on every possible stage while knowing they
failed to stop me."

"That's very dramatic," Suiren observed.

"I'm an idol. We're SUPPOSED to be dramatic."

Sora's grin returned, sharp and delighted.

"Oh, I really, REALLY like her."

"Her spite is admirable," Suiren agreed, and there was something
almost warm in her voice. "It will serve us well."

I looked at them---my team, my allies, my friends.

The manic speedster who ran so fast she forgot to take care of herself.

The elegant prodigy who'd perfected every movement but lost herself in
the process.

And me. The shameless disaster who'd clawed her way into this
tournament through pure audacity and refused to be erased.

We were all broken in our own ways.

Maybe that's why we fit.

"Alright," I said. "Let's talk strategy. The next round starts
tomorrow, and I have a reputation to build."


---



---


*Thus began the legend of Ika Minami.*

*The girl who refused to disappear.*

*The idol who broke every rule.*

*The disaster who became infinite.*

*But that's a story for the next volume.*


---


Afterword

Hello, dear reader. Ika here.

If you've made it this far, I have two things to say:

First, thank you. Seriously. Whether you picked up this book because you
liked the premise, the cover, or just wanted to see what kind of
disaster would actually commit to a title this long---thank you for
giving me your time.

Second, I need to address something.

Yes, this is a story about attractive people in revealing outfits
competing to catch a mysterious pretty boy. Yes, there's fanservice.
Yes, clothes malfunction with suspicious frequency.

But here's the thing.

This is also a story about being seen. About fighting to exist in a
world that would rather you disappear. About finding your people---the
ones who see the real you beneath the performance and love you anyway.

My forty-seven taught me that.

Before I had ten thousand fans, before I crashed the qualifiers, before
any of this---I had forty-seven people who showed up every stream. Who
stuck around when the numbers were pathetic and the content was
desperate and I was barely holding myself together.

They didn't just watch me. They SAW me.

And that made all the difference.

So this book is for them. For everyone who's ever felt invisible. For
everyone who's been told they're too much, too desperate, too
shameless for wanting to be noticed.

You're not too much.

You're exactly enough.

And if the world won't make space for you?

Well.

You do what I did.

You show up anyway, looking incredible, and refuse to apologize.

See you in Volume 2.

--- Ika Minami

*(The author would like to note that the protagonist has once again
hijacked the afterword. She's been doing this since the prologue. The
author has accepted this as her fate.)*

INFINITE IDOL

*Volume 1: The Awakening Arc*

END

*To be continued in Volume 2:*

*"The Queen's Gambit"*

*May your devotion never waver.*
